package filrouge;

import org.junit.jupiter.api.*;

import filrouge.entity.Weapon;
import filrouge.services.WeaponServices;
import filrouge.utils.DBManager;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Savepoint;
//import java.util.ArrayList;

public class WeaponTest {
    Savepoint save;

    @BeforeAll
    public static void setup() {
        DBManager.init();
        DBManager.setAutoCommit(false);
    }

    @BeforeEach
    public void init() {
        save = DBManager.setSavePoint();
    }

    @AfterEach
    public void done() {
        DBManager.rollback(save);
    }

    @AfterAll
    public static void tearDown() {
        DBManager.close();
    }

    @Test
    public void SaveTest() {
        Weapon weapon1 = new Weapon();

        weapon1.setName("Arme de fouuu !");
        weapon1.setType(1);
        weapon1.setIconUrl("");
        weapon1.setDamage(10);
        weapon1.setCritical(0.2f);
        weapon1.setLevel(1);
        weapon1.setPrice(10);

        WeaponServices weaponServices = new WeaponServices();
        assertTrue(weaponServices.createWeapon(weapon1));

    }

    @Test
    public void UpdateTest() {
        Weapon weapon1 = new Weapon();

        weapon1.setName("Super Arme !");
        weapon1.setType(1);
        weapon1.setCritical(0.2f);
        weapon1.setIconUrl("");
        weapon1.setDamage(10);
        weapon1.setPrice(10);
        WeaponServices weaponServices = new WeaponServices();

        weaponServices.createWeapon(weapon1);

        Weapon weapon2 = weapon1;
        weapon2.setDamage(5);
        weaponServices.update(weapon2);
        assertTrue(weaponServices.update(weapon2));
    }

    @Test
    public void getAllWeaponsTest() {
        // we check if the size of the list after insertion of a weapon in the DB is
        // greater than the previous value
        WeaponServices weaponServices = new WeaponServices();

        Weapon weapon1 = new Weapon();

        weapon1.setName("Super Arme !");
        weapon1.setIconUrl("");
        weapon1.setType(1);
        weapon1.setDamage(10);
        weapon1.setCritical(0.2f);
        weapon1.setLevel(4);
        weapon1.setPrice(10);
        int sizeBeforeInsert = weaponServices.getAll().size();
        weaponServices.createWeapon(weapon1);
        int sizeAfterInsert = weaponServices.getAll().size();

        assertTrue(sizeBeforeInsert < sizeAfterInsert);

    }

    @Test
    public void deleteWeaponTest() {
        // we first create a weapon
        Weapon weapon1 = new Weapon();

        weapon1.setName("Super Arme !");
        weapon1.setIconUrl("");
        weapon1.setType(1);
        weapon1.setDamage(10);
        weapon1.setCritical(0.2f);
        weapon1.setLevel(4);
        weapon1.setPrice(10);

        // we save it into the DB
        WeaponServices weaponServices = new WeaponServices();
        weaponServices.createWeapon(weapon1);

        // we check if the weapon has an id different from the initial value id=0
        assertNotEquals(0, weapon1.getId());

        // we delete it
        assertTrue(weaponServices.delete(weapon1.getId()));

    }

    @Test
    public void getWeaponByIdTest() {
        // we first create a weapon
        Weapon weapon1 = new Weapon();

        weapon1.setName("Super Arme !");
        weapon1.setIconUrl("");
        weapon1.setType(1);
        weapon1.setDamage(10);
        weapon1.setCritical(0.2f);
        weapon1.setLevel(4);
        weapon1.setPrice(10);

        // we save it into the DB
        WeaponServices weaponServices = new WeaponServices();
        weaponServices.createWeapon(weapon1);

        // we check if the weapon has an id different from the initial value id=0
        assertNotEquals(0, weapon1.getId());

        // we test the getById method
        assertNotNull(weaponServices.getById(weapon1.getId()));

    }

}
