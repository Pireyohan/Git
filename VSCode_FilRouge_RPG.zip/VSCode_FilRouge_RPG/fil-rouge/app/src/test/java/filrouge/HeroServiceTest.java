package filrouge;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Savepoint;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import filrouge.entity.Hero;
import filrouge.entity.Weapon;
import filrouge.services.HeroServices;
import filrouge.services.WeaponServices;
import filrouge.utils.DBManager;

public class HeroServiceTest {
    // #region attributs
    Savepoint save;

    // #endregion attributs

    // #region tear/down

    @BeforeAll
    public static void setup() {
        DBManager.init();
        DBManager.setAutoCommit(false);
    }

    @BeforeEach
    public void init() {
        save = DBManager.setSavePoint();
    }

    @AfterEach
    public void done() {
        DBManager.rollback(save);
    }

    @AfterAll
    public static void tearDown() {
        DBManager.close();
    }
    // #endregion tear/down

    // #region methods tests
    @Test
    public void createHeroTest() {

        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        // hero.setIdArmorEquiped(1);
        // hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");
        hero.setLevel(5);

        HeroServices heroServices = new HeroServices();
        assertTrue(heroServices.createHero(hero));

    }

    @Test
    public void getHeroByIdTest() {
        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        hero.setIdArmorEquiped(1);
        hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");

        HeroServices heroServices = new HeroServices();
        heroServices.createHero(hero);

        assertNotEquals(heroServices.getById(hero.getId()), 0);
        // assertNull(heroServices.getById(200).getId());

    }

    @Test
    public void getAllHeroesTest() {
        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        hero.setIdArmorEquiped(1);
        hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");

        HeroServices heroServices = new HeroServices();
        int initialSize = heroServices.getAll().size();

        heroServices.createHero(hero);

        int finalsize = heroServices.getAll().size();

        assertTrue(initialSize < finalsize);

    }

    @Test
    public void updateHeroTest() {
        HeroServices heroServices = new HeroServices();

        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        hero.setIdArmorEquiped(1);
        hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");

        heroServices.createHero(hero);

        hero.setName("rachid");
        hero.setHp(20);
        assertTrue(heroServices.update(hero));
    }

    @Test
    public void deleteHeroTest() {
        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        hero.setIdArmorEquiped(1);
        hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");

        HeroServices heroService = new HeroServices();
        heroService.createHero(hero);
        Hero hero2 = heroService.getById(hero.getId());
        int idHero = hero2.getId();
        boolean suppressionIsSuccessful = heroService.delete(idHero);
        assertTrue(suppressionIsSuccessful);
    }

    @Test
    public void equipWeaponTest() {
        Hero hero = new Hero();

        hero.setName("Ra");
        hero.setHp(5);
        hero.setHpMax(7);
        hero.setStrength(8);
        hero.setDefense(9);
        hero.setSpeed(10);
        hero.setMoney(11);
        hero.setExperience(11);
        hero.setCritical(11.5f);
        hero.setDodge(11.5f);
        // hero.setIdArmorEquiped(1);
        // hero.setIdWeaponEquiped(1);
        hero.setRace("paladin");
        hero.setLevel(5);

        HeroServices heroServices = new HeroServices();
        WeaponServices weaponServices = new WeaponServices();
        heroServices.createHero(hero);

        ArrayList<Weapon> weapons = weaponServices.getAll();
        Weapon weapon1 = new Weapon();
        if (weapons.size() > 0) {

            weapon1 = weapons.get(0);
        } else {
            weapon1 = new Weapon();

            weapon1.setId(1);
        }

        assertNotNull(heroServices.equipWeapon(hero, weapon1));
    }
    // #endregion methods tests

}
