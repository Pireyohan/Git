package filrouge;

import org.junit.jupiter.api.*;

import filrouge.entity.Armor;
import filrouge.services.ArmorServices;
import filrouge.utils.DBManager;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Savepoint;

public class ArmorTest {
    Savepoint save;

    @BeforeAll
    public static void setup() {
        DBManager.init();
        DBManager.setAutoCommit(false);
    }

    @BeforeEach
    public void init() {
        save = DBManager.setSavePoint();
    }

    @AfterEach
    public void done() {
        DBManager.rollback(save);
    }

    @AfterAll
    public static void tearDown() {

    }

    @Test
    public void createArmorTest() {
        Armor armor1 = new Armor();
        armor1.setName(" Armor !");
        armor1.setIconUrl("");

        armor1.setType(1);
        armor1.setProtection(10);
        armor1.setDodgeRate(0.2f);
        armor1.setLevel(4);

        armor1.setPrice(1);
        ArmorServices armorServices = new ArmorServices();
        assertTrue(armorServices.createArmor(armor1));

    }

    @Test
    public void getByIdTest() {
        Armor armor1 = new Armor();
        armor1.setName(" Armor !");
        armor1.setIconUrl("");

        armor1.setType(1);
        armor1.setProtection(10);
        armor1.setDodgeRate(0.2f);
        armor1.setLevel(4);

        armor1.setPrice(1);
        ArmorServices armorServices = new ArmorServices();
        armorServices.createArmor(armor1);
        assertNotEquals(armorServices.getById(armor1.getId()), 0);
        // assertNotNull(armorServices.getById(200).getId());

    }

    @Test
    public void getAllTest() {
        Armor armor1 = new Armor();
        armor1.setName(" Armor !");
        armor1.setIconUrl("");

        armor1.setType(1);
        armor1.setProtection(10);
        armor1.setDodgeRate(0.2f);
        armor1.setLevel(4);

        armor1.setPrice(1);
        ArmorServices armorServices = new ArmorServices();
        int initial = armorServices.getAll().size();
        armorServices.createArmor(armor1);
        int tableAfter = armorServices.getAll().size();
        assertTrue(initial < tableAfter);

    }

    @Test
    public void getUpdateTest() {

        Armor armor1 = new Armor();
        armor1.setName(" Armor !");
        armor1.setIconUrl("");

        armor1.setType(1);
        armor1.setProtection(10);
        armor1.setDodgeRate(0.2f);
        armor1.setLevel(4);

        armor1.setPrice(1);
        ArmorServices armorServices = new ArmorServices();
        armorServices.createArmor(armor1);
        armor1.setLevel(15);
        assertTrue(armorServices.update(armor1));

    }

    @Test
    public void deleteTest() {

        ArmorServices armorServices = new ArmorServices();
        Armor armor1 = armorServices.getById(1);
        assertTrue(armorServices.delete(armor1.getId()));

    }

}