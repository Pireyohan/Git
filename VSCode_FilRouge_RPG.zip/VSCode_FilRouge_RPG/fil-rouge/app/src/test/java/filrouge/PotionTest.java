package filrouge;

import org.junit.jupiter.api.*;

import filrouge.entity.Potion;

import filrouge.services.PotionServices;
import filrouge.utils.DBManager;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.Savepoint;

public class PotionTest {

    Savepoint save;

    @BeforeAll
    public static void setup() {
        DBManager.init();
        DBManager.setAutoCommit(false);
    }

    @BeforeEach
    public void init() {
        save = DBManager.setSavePoint();
    }

    @AfterEach
    public void done() {
        DBManager.rollback(save);
    }

    @AfterAll
    public static void tearDown() {
        DBManager.close();
    }

    @Test

    public void createPotionTest() {
        Potion potion1 = new Potion();

        potion1.setName("Super Popo de ouf !");
        potion1.setIconUrl("");
        potion1.setTypePotion(3);
        potion1.setHpRestore(100);
        potion1.setLevel(6);
        potion1.setPrice(50);
        potion1.setQuantity(5);

        PotionServices potionServices = new PotionServices();
        assertTrue(potionServices.createPotion(potion1));
    }

    @Test
    public void getByIdTest() {
        Potion potion1 = new Potion();

        potion1.setName("Super Popo de ouf !");
        potion1.setIconUrl("");
        potion1.setTypePotion(3);
        potion1.setHpRestore(100);
        potion1.setLevel(6);
        potion1.setPrice(50);
        potion1.setQuantity(5);

        PotionServices potionServices = new PotionServices();
        potionServices.createPotion(potion1);

        assertNotEquals(potionServices.getById(potion1.getId()), 0);

    }

    @Test
    public void getAllTest() {
        PotionServices potionServices = new PotionServices();
        Potion potion1 = new Potion();

        potion1.setName("Super Popo de ouf !");
        potion1.setIconUrl("");
        potion1.setTypePotion(3);
        potion1.setHpRestore(100);
        potion1.setLevel(6);
        potion1.setPrice(50);
        potion1.setQuantity(5);

        int initialSize = potionServices.getAll().size();
        potionServices.createPotion(potion1);
        int finalSize = potionServices.getAll().size();
        assertTrue(initialSize < finalSize);

    }

    @Test
    public void UpdateTest() {
        Potion potion1 = new Potion();

        potion1.setName("Super Popo de ouf !");
        potion1.setIconUrl("");
        potion1.setTypePotion(3);
        potion1.setHpRestore(100);
        potion1.setLevel(6);
        potion1.setPrice(50);
        potion1.setQuantity(5);

        PotionServices potionServices = new PotionServices();
        potionServices.createPotion(potion1);

        Potion potion2 = potionServices.getById(potion1.getId());
        potion2.setHpRestore(55);
        potionServices.createPotion(potion2);

        potion1.getId();

        assertFalse(potion1.getHpRestore() == potion2.getHpRestore());
    }

    @Test
    public void deleteTest() {
        PotionServices potionServices = new PotionServices();
        Potion potion = new Potion();

        potion.setName("test");
        potion.setIconUrl("https");
        potion.setTypePotion(1);
        potion.setHpRestore(50);
        potion.setLevel(2);
        potion.setQuantity(2);
        potion.setPrice(2);

        potionServices.createPotion(potion);

        Potion potion1 = potionServices.getById(potion.getId());

        assertTrue(potionServices.delete(potion1.getId()));

    }

}
