package filrouge;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Savepoint;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import filrouge.entity.Monster;
import filrouge.services.MonsterServices;
import filrouge.utils.DBManager;

public class MonsterTest {
    Savepoint save;

    @BeforeAll
    public static void setup() {
        DBManager.init();
        DBManager.setAutoCommit(false);
    }

    @BeforeEach
    public void init() {
        save = DBManager.setSavePoint();
    }

    @AfterEach
    public void done() {
        DBManager.rollback(save);
    }

    @AfterAll
    public static void tearDown() {
        DBManager.close();
    }

    @Test
    public void getMonsterByIdTest() {
        MonsterServices service = new MonsterServices();

        assertNotNull(service.getById(1));

    }

    @Test
    public void monsterGetAllTest() {
        ArrayList<Monster> monsters = new ArrayList<>();
        MonsterServices monsterServices = new MonsterServices();
        int initialSize = monsters.size();
        ArrayList<Monster> monsters2 = monsterServices.getAll();
        int monstersListSize = monsters2.size();
        boolean tableauNonVide = monstersListSize > initialSize ? true : false;
        assertTrue(tableauNonVide);
    }

}
