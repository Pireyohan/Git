package filrouge.allInterfaces;

import java.util.ArrayList;

import filrouge.entity.Potion;

public interface IPotion {

    public boolean createPotion(Potion potion);

    public Potion getById(int id);

    public ArrayList<Potion> getAll(); // dans un second temps

    public boolean update(Potion potion);

    public boolean delete(int id);

}
