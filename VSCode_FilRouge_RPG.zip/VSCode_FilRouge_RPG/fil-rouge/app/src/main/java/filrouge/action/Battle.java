package filrouge.action;

import filrouge.allInterfaces.IBattleAction;
import filrouge.entity.Hero;
import filrouge.entity.Monster;

public class Battle {
    int input;
    private Hero player;
    private Monster enemy;
    private IBattleAction playerAction;

    public Battle(Hero thePlayer, Monster theEnnemy) {
        player = thePlayer;
        enemy = theEnnemy;
        fight();
    }

    private void fight() {
        while (player.getHp() > 0 && enemy.getHp() > 0) {
            playerAction = BattleHelper.getBattleAction(player, enemy); // poll for input to get choice of action
            player.takeTurn(playerAction, enemy); // pass the enemy encase decision was to attack
            BattleHelper.displayTurnResult(playerAction, enemy);
        }
    }

}
