package filrouge.allInterfaces;

import java.util.ArrayList;

import filrouge.entity.Weapon;

public interface IWeapon {

    public boolean createWeapon(Weapon weapon);

    public Weapon getById(int id);

    public ArrayList<Weapon> getAll(); // dans un second temps

    public boolean update(Weapon weapon);

    public boolean delete(int id);

}
