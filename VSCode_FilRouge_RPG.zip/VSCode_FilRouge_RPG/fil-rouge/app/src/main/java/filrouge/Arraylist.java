package filrouge;

public class Arraylist<T> {

}
