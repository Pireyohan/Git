package filrouge.allInterfaces;

import java.util.ArrayList;

import filrouge.entity.Hero;

public interface IHero {

    public boolean createHero(Hero hero);

    public Hero getById(int id);

    public ArrayList<Hero> getAll();

    public boolean update(Hero hero);

    public boolean delete(int id);
}
