package filrouge.entity;

import filrouge.allInterfaces.IEquiped;

public class Weapon extends Item implements IEquiped {

    // Declare variables
    protected int type = 0; // faire un type armure lourde =false , type armure legere= true
    protected int damage = 0;
    protected float critical = 0.0f;
    // protected int cost = 0;
    protected int level = 0;
    protected int price = 0;

    public Weapon() {
        super("");
    }

    // #region Constructor
    public Weapon(String name) {
        super("toto");
    }

    public Weapon(String name, int type, int damage, float critical, int cost, int level) {
        super(name);
        this.type = type;
        this.damage = damage;
        this.critical = critical;
        // this.cost = cost;
        this.level = level;
    }

    // #endregion
    // #region get() / get(int id )/ save() Old Version
    // public boolean get() {
    // try {
    // ResultSet result = DBManager.execute("SELECT * FROM weapon WHERE idWeapon = "
    // + this.id);
    // if (result.next()) {
    // this.name = result.getString("name");
    // this.iconUrl = result.getString("iconUrl");
    // this.type = result.getBoolean("type");
    // this.damage = result.getInt("damage");
    // this.critical = result.getFloat("criticalHit");
    // this.level = result.getInt("level");
    // this.cost = result.getInt("price");
    // return true;
    // }

    // } catch (Exception ex) {
    // System.out.println("SQLException: " + ex.getMessage());
    // System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
    // System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
    // }
    // return false;
    // }

    // public boolean get(int id) {
    // try {
    // ResultSet result = DBManager.execute("SELECT * FROM weapon WHERE idWeapon = "
    // + id);
    // if (result.next()) {
    // this.name = result.getString("name");
    // this.iconUrl = result.getString("iconUrl");
    // this.type = result.getBoolean("type");
    // this.damage = result.getInt("damage");
    // this.critical = result.getFloat("criticalHit");
    // this.level = result.getInt("level");
    // this.cost = result.getInt("price");
    // this.id = id;
    // return true;
    // }

    // } catch (Exception ex) {
    // System.out.println("SQLException: " + ex.getMessage());
    // System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
    // System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
    // }
    // return false;
    // }

    // #endregion

    // #region Getter SEtter
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getType() {
        return type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public float getCritical() {
        return critical;
    }

    public void setCritical(float critical) {
        this.critical = critical;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    // #endregion

}
