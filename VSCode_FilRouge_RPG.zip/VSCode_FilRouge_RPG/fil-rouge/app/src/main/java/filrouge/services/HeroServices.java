package filrouge.services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import filrouge.allInterfaces.IHero;

import filrouge.entity.Hero;
import filrouge.entity.Weapon;
import filrouge.utils.DBManager;

public class HeroServices implements IHero {
    // #region attributs

    // #endregion attributs

    public static final String Hero = null;

    // #region methods
    @Override
    public boolean createHero(Hero hero) {
        String sql = "";
        // ArrayList<Weapon> weaponList = new ArrayList<>();
        // ArrayList<Armor> armorList = new ArrayList<>();
        // WeaponServices weaponServices = new WeaponServices();
        // ArmorServices armorServices = new ArmorServices();
        // weaponList = weaponServices.getAll();
        // armorList = armorServices.getAll();
        // Armor armor1 = armorList.get(0);

        // hero.setIdArmorEquiped(armor1.getId());
        // hero.setIdWeaponEquiped(weaponList.get(0).getId());
        if (hero.getId() == 0) {
            sql = "INSERT INTO hero(name, hp,hpMax, strength, defense, speed, money, experience, critical,dodge,level,race)"
                    + " values(?,?,?,?,?,?,?,?,?,?,?,?);";
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, hero.getName());
                pstmt.setInt(2, hero.getHp());
                pstmt.setInt(3, hero.getHpMax());
                pstmt.setInt(4, hero.getStrength());
                pstmt.setInt(5, hero.getDefense());
                pstmt.setInt(6, hero.getSpeed());
                pstmt.setInt(7, hero.getMoney());
                pstmt.setInt(8, hero.getExperience());
                pstmt.setFloat(9, hero.getCritical());
                pstmt.setFloat(10, hero.getDodge());
                pstmt.setInt(11, hero.getLevel());
                pstmt.setString(12, hero.getRace());

                pstmt.executeUpdate();
                sql = "INSERT INTO heroWeaponInventory(id_hero, idWeaponEquiped) values(" + hero.getIdArmorEquiped()
                        + "," + "1" + ")";
                ResultSet keys = pstmt.getGeneratedKeys();
                if (hero.getId() == 0 && keys.next()) {
                    hero.setId(keys.getInt(1));
                    return true;
                } else if (hero.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;

    }

    @Override
    public Hero getById(int id) {
        Hero hero = new Hero();
        try {
            ResultSet result = DBManager.execute("select * from hero where idHero=" + id);
            if (result.next()) {
                hero.setName(result.getString("name"));
                hero.setHp(result.getInt("hp"));
                hero.setHpMax(result.getInt("hpMax"));
                hero.setStrength(result.getInt("strength"));
                hero.setDefense(result.getInt("defense"));
                hero.setSpeed(result.getInt("speed"));
                hero.setMoney(result.getInt("money"));
                hero.setExperience(result.getInt("experience"));
                hero.setCritical(result.getFloat("critical"));
                hero.setDodge(result.getFloat("dodge"));
                hero.setLevel(result.getInt("level"));
                hero.setIdWeaponEquiped(result.getInt("idWeaponEquiped"));
                hero.setIdArmorEquiped(result.getInt("idArmorEquiped"));
                hero.setId(result.getInt("idHero"));
                hero.setRace(result.getString("race"));
                return hero;
            }

        } catch (SQLException ex) {
            System.out.println("SQLException:" + ex.getMessage());
            System.out.println("SQLState:" + ex.getSQLState());
            System.out.println("VendorError:" + ex.getErrorCode());

        }

        return null;
    }

    @Override
    public ArrayList<Hero> getAll() {
        ArrayList<Hero> heros = new ArrayList<>();
        Hero hero = new Hero();
        try {
            ResultSet result = DBManager.execute("SELECT * FROM hero");
            while (result.next()) {
                hero.setName(result.getString("name"));
                hero.setHp(result.getInt("hp"));
                hero.setHpMax(result.getInt("hpMax"));
                hero.setStrength(result.getInt("strength"));
                hero.setDefense(result.getInt("defense"));
                hero.setSpeed(result.getInt("speed"));
                hero.setMoney(result.getInt("money"));
                hero.setExperience(result.getInt("experience"));
                hero.setCritical(result.getFloat("critical"));
                hero.setDodge(result.getFloat("dodge"));
                hero.setLevel(result.getInt("level"));
                hero.setIdWeaponEquiped(result.getInt("idWeaponEquiped"));
                hero.setIdArmorEquiped(result.getInt("idArmorEquiped"));
                hero.setId(result.getInt("idHero"));
                hero.setRace(result.getString("race"));
                hero.setId(result.getInt("idHero"));
                heros.add(hero);
            }
            return heros;
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return heros.size() == 0 ? null : heros;
    }

    @Override
    public boolean update(Hero hero) {
        String sql = "";
        if (hero.getId() != 0) {
            sql = "UPDATE hero SET name=?, hp=?,hpMax=?, strength=?, defense=?, speed=?, money=?, experience=?, critical=?,dodge=?,level=?,race=?,idWeaponEquiped=?,idArmorEquiped=?"
                    + " WHERE idHero= ?;";
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, hero.getName());
                pstmt.setInt(2, hero.getHp());
                pstmt.setInt(3, hero.getHpMax());
                pstmt.setInt(4, hero.getStrength());
                pstmt.setInt(5, hero.getDefense());
                pstmt.setInt(6, hero.getSpeed());
                pstmt.setInt(7, hero.getMoney());
                pstmt.setInt(8, hero.getExperience());
                pstmt.setFloat(9, hero.getCritical());
                pstmt.setFloat(10, hero.getDodge());
                pstmt.setInt(11, hero.getLevel());
                pstmt.setString(12, hero.getRace());
                pstmt.setInt(13, hero.getIdWeaponEquiped());
                pstmt.setInt(14, hero.getIdArmorEquiped());
                pstmt.setInt(15, hero.getId());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (hero.getId() == 0 && keys.next()) {
                    hero.setId(keys.getInt(1));
                    return true;
                } else if (hero.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;
    }

    @Override
    public boolean delete(int id) {
        Hero hero = getById(id);
        if (hero == null) {
            System.out.println("Impossible de supprimer le héro avec l'id : " + id);
            return false;

        } else {

            int result = DBManager.executeUpdate("DELETE FROM hero WHERE idHero=" + id + ";");
            return result != 0 ? true : false;
        }

    }

    public Hero equipWeapon(Hero hero, Weapon weapon) {
        if (hero == null) {
            return null;
        }
        if (weapon == null) {
            return null;
        }
        hero.setIdWeaponEquiped(weapon.getId());
        update(hero);
        DBManager.executeUpdate("DELETE FROM heroWeaponInventory WHERE id_weapon=" + weapon.getId() + ";");
        return hero;
    }

    // #endregion methods

}
