package filrouge.allInterfaces;

public interface IEquiped {

    // public boolean equip(Hero target);

    // public boolean unequip(Hero target);
}

