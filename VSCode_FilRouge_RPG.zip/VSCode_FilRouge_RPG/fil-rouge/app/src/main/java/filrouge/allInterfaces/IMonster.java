package filrouge.allInterfaces;

import java.util.ArrayList;

import filrouge.entity.Monster;

public interface IMonster {
    // public boolean createWeapon(Monster monster);

    public Monster getById(int id);

    public ArrayList<Monster> getAll();

    // public boolean update(Monster monster);

    // public boolean delete(int id);

}
