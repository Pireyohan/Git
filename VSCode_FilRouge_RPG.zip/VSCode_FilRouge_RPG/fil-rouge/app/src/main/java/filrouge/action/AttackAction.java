package filrouge.action;

import filrouge.allInterfaces.IBattleAction;
import filrouge.entity.Hero;
import filrouge.entity.Monster;

public class AttackAction implements IBattleAction {

    Hero target;
    Monster target2;
    public int damage;
    String result;

    AttackAction(Monster target2, int damage, String result) {
        this.target2 = target2;
        this.damage = damage;
        this.result = result;
    }

    public void execute() {
        target.decreaseHealth(damage);
    }

   

    public String getResult() {
        return result;
    }

}
