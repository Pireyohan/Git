package filrouge.entity;

import filrouge.allInterfaces.IConsomable;

public class Potion extends Item implements IConsomable {

    // Declare variables
    protected int typePotion = 0;
    protected int hpRestore = 0;
    protected int level = 0;
    protected int quantity = 0;
    protected int price = 0;

    // #region Constructor

    public Potion() {
        super("");
    }

    public Potion(String name) {
        super("popo");
    }

    public Potion(String name, int typePotion, int hpRestore, int level, int quantity, int price) {
        super(name);
        this.typePotion = typePotion;
        this.hpRestore = hpRestore;
        this.level = level;
        this.quantity = quantity;
        this.price = price;
    }

    // #endregion

    // #region Getter Setter
    public int getTypePotion() {
        return typePotion;
    }

    public void setTypePotion(int typePotion) {
        this.typePotion = typePotion;
    }

    public int getHpRestore() {
        return hpRestore;
    }

    public void setHpRestore(int hpRestore) {
        this.hpRestore = hpRestore;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    // #endregion getter and setter

}
