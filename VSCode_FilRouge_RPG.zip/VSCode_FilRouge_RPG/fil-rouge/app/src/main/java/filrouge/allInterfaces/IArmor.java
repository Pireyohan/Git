package filrouge.allInterfaces;

import java.util.ArrayList;

import filrouge.entity.Armor;

public interface IArmor {

    public boolean createArmor(Armor armor);

    public Armor getById(int id); 
       

    public ArrayList<Armor> getAll(); // dans un second temps 

    public boolean update(Armor armor);

    public boolean delete(int id);
    
}
