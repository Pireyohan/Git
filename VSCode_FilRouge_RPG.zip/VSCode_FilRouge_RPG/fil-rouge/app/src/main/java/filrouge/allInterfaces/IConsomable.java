package filrouge.allInterfaces;

public interface IConsomable {

    //public void consume(Hero target);
}
