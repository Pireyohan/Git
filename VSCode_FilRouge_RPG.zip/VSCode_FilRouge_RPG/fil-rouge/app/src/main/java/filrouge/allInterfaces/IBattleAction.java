package filrouge.allInterfaces;

public interface IBattleAction {

    void execute();

    String getResult();
}
