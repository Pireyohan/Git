package filrouge.action;

import filrouge.allInterfaces.IBattleAction;

public class FaintedAction implements IBattleAction {
    String outcomeText;

    @Override
    public void execute() {
        // outcomeText = (user.getName() + " fainted...");
    }

    @Override
    public String getResult() {

        return null;
    };
}
