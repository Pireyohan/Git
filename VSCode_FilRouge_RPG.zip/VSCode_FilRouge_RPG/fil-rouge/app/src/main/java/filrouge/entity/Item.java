package filrouge.entity;

public class Item  {

    protected String name = "";
    protected String iconUrl= "";
    protected int id;
    

    public Item(String name) {
        this.name=name;
    }
    
 

    //#region Getter Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    //#endregion
    
}
