package filrouge.entity;

public class Monster extends Entity {
    // #region attributs
    protected String name;
    protected Armor armor;
    protected Weapon weapon;
    // #endregion attributs

    // #region getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Armor getArmor() {
        return armor;
    }

    public void setArmor(Armor armor) {
        this.armor = armor;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
    // #endregion getters and setters

    // #region methods
    @Override
    public int attack() {
        return (int) (Math.random() * (hp / 4 + 1) + hp / 4 + 3);
    }
    // #endregion methods

    @Override
    public int defend() {

        return 0;
    }

}
