package filrouge.services;

import java.sql.ResultSet;
import java.util.ArrayList;
import filrouge.allInterfaces.IPotion;
import filrouge.entity.Potion;
import filrouge.utils.DBManager;
import java.sql.*;

public class PotionServices implements IPotion {

    @Override
    public boolean createPotion(Potion potion) {
        String sql = "";
        if (potion.getId() == 0) {
            sql = "INSERT INTO potion (name, iconUrl, type, hpRestore, level, quantity, price )" +
                    "VALUES(?, ?, ?, ?, ?, ?, ? )";
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, potion.getName());
                pstmt.setString(2, potion.getIconUrl());
                pstmt.setInt(3, potion.getTypePotion());
                pstmt.setInt(4, potion.getHpRestore());
                pstmt.setInt(5, potion.getLevel());
                pstmt.setInt(6, potion.getQuantity());
                pstmt.setInt(7, potion.getPrice());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (potion.getId() == 0 && keys.next()) {
                    potion.setId(keys.getInt(1));
                    return true;
                } else if (potion.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;

    }

    @Override
    public Potion getById(int id) {
        Potion potion = new Potion();
        try {
            ResultSet result = DBManager.execute("SELECT * FROM potion WHERE idPotion = "
                    + id);
            if (result.next()) {
                potion.setName(result.getString("name"));
                potion.setIconUrl(result.getString("iconUrl"));
                potion.setTypePotion(result.getInt("type"));
                potion.setHpRestore(result.getInt("hpRestore"));
                potion.setLevel(result.getInt("level"));
                potion.setPrice(result.getInt("price"));
                potion.setQuantity(result.getInt("quantity"));
                potion.setId(id);

                return potion;
            }

        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return null;
    }

    @Override
    public ArrayList<Potion> getAll() {
        ArrayList<Potion> potions = new ArrayList<>();
        Potion potion = new Potion();

        try {
            ResultSet result = DBManager.execute("SELECT * FROM potion ");
            while (result.next()) {
                potion.setName(result.getString("name"));
                potion.setIconUrl(result.getString("iconUrl"));
                potion.setTypePotion(result.getInt("type"));
                potion.setHpRestore(result.getInt("hpRestore"));
                potion.setLevel(result.getInt("level"));
                potion.setPrice(result.getInt("price"));
                potion.setQuantity(result.getInt("quantity"));
                potion.setId(result.getInt("idPotion"));
                potions.add(potion);
            }
            return potions;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return potions.size() == 0 ? null : potions;

    }

    @Override
    public boolean update(Potion potion) {
        String sql = "";
        ;
        if (potion.getId() == 0)
            sql = "UPDATE potion " +
                    "SET name = ?, type = ?, hpRestore = ?, level = ?, quantity = ?, price= ? " +
                    "WHERE idPotion = ?";
        try {
            PreparedStatement stmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, potion.getName());
            stmt.setInt(2, potion.getTypePotion());
            stmt.setInt(3, potion.getHpRestore());
            stmt.setInt(4, potion.getLevel());
            stmt.setInt(5, potion.getQuantity());
            stmt.setInt(6, potion.getPrice());

            stmt.executeUpdate();

            ResultSet keys = stmt.getGeneratedKeys();
            if (potion.getId() == 0 && keys.next()) {
                potion.setId(keys.getInt(1));
                return true;
            } else if (potion.getId() != 0)
                return true;
            else
                return false;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        Potion potion = getById(id);
        if (potion == null) {
            System.out.println("Impossible de supprimer la potion avec l'id : " + id);
            return false;

        } else {

            int result = DBManager.executeUpdate("DELETE FROM potion WHERE idPotion=" + id + ";");
            return result != 0 ? true : false;
        }
    }

}
