package filrouge.action;

public class MessageBuilder {
    public static String inputPrompt(String userName) {
        return (userName + "'s turn\nSelect an action\n1. Attack | 2. Do Nothing");
    }

    public static String attackAction(String userName, int damage) {
        return (userName + " hits for " + damage + "\n");
    }

    public static String noAction(String userName) {
        return (userName + " is loafing around...");
    }
}
