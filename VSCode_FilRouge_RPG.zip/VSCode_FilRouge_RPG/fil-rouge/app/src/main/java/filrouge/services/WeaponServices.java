package filrouge.services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import filrouge.allInterfaces.IWeapon;
import filrouge.entity.Weapon;
import filrouge.utils.DBManager;

public class WeaponServices implements IWeapon {

    @Override
    public boolean createWeapon(Weapon weapon) {
        String sql = "";
        if (weapon.getId() == 0) {
            sql = "INSERT INTO weapon (name,iconUrl,type,damage,criticalHit,level,price)" +
                    "VALUES(?,?,?,?,?,?,?)";// 7 parameters
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, weapon.getName());
                pstmt.setString(2, weapon.getIconUrl());
                pstmt.setInt(3, weapon.getType());
                pstmt.setInt(4, weapon.getDamage());
                pstmt.setFloat(5, weapon.getCritical());
                pstmt.setInt(6, weapon.getLevel());
                pstmt.setInt(7, weapon.getPrice());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (weapon.getId() == 0 && keys.next()) {
                    weapon.setId(keys.getInt(1));
                    return true;
                } else if (weapon.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;

    }

    @Override
    public boolean update(Weapon weapon) {
        String sql = "";
        if (weapon.getId() != 0) {
            sql = "UPDATE weapon " +
                    "SET name=?,iconUrl=?,type=?,damage=?,criticalHit=?,level=?,price=? " +
                    "WHERE idWeapon=?";
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, weapon.getName());
                pstmt.setString(2, weapon.getIconUrl());
                pstmt.setInt(3, weapon.getType());
                pstmt.setInt(4, weapon.getDamage());
                pstmt.setFloat(5, weapon.getCritical());
                pstmt.setInt(6, weapon.getLevel());
                pstmt.setInt(7, weapon.getPrice());
                pstmt.setInt(8, weapon.getId());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (weapon.getId() == 0 && keys.next()) {
                    weapon.setId(keys.getInt(1));
                    return true;
                } else if (weapon.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;

    }

    @Override
    public Weapon getById(int id) {
        Weapon weapon = new Weapon();
        try {
            ResultSet result = DBManager.execute("SELECT * FROM weapon WHERE idWeapon = "
                    + id);
            if (result.next()) {
                weapon.setName(result.getString("name"));
                weapon.setIconUrl(result.getString("iconUrl"));
                weapon.setType(result.getInt("type"));
                weapon.setDamage(result.getInt("damage"));
                weapon.setCritical(result.getInt("criticalHit"));
                weapon.setLevel(result.getInt("level"));
                weapon.setPrice(result.getInt("price"));
                weapon.setId(id);
                return weapon;
            }

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return null;

    }

    @Override
    public ArrayList<Weapon> getAll() {
        ArrayList<Weapon> weapons = new ArrayList<>();
        Weapon weapon = new Weapon();
        ResultSet result = DBManager.execute("SELECT * FROM weapon");
        try {

            while (result.next()) {
                weapon.setName(result.getString("name"));
                weapon.setIconUrl(result.getString("iconUrl"));
                weapon.setType(result.getInt("type"));
                weapon.setDamage(result.getInt("damage"));
                weapon.setCritical(result.getInt("criticalHit"));
                weapon.setLevel(result.getInt("level"));
                weapon.setPrice(result.getInt("price"));

                weapons.add(weapon);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return weapons;
    }

    @Override
    public boolean delete(int id) {

        int result = DBManager.executeUpdate("DELETE FROM weapon WHERE idWeapon=" + id + ";");
        return result == 0 ? false : true;

    }

}
