package filrouge.action;

import filrouge.allInterfaces.IBattleAction;

public class NoAction implements IBattleAction {
    String result;

    NoAction(String result) {
        this.result = result;
    }

    public void execute() {
    }

    public String getResult() {
        return result;
    }
}
