package filrouge.services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import filrouge.allInterfaces.IArmor;
import filrouge.entity.Armor;
import filrouge.utils.DBManager;

public class ArmorServices implements IArmor {

    @Override
    public Armor getById(int id) {
        Armor armor = new Armor();
        try {
            ResultSet result = DBManager.execute("SELECT * FROM  armor WHERE idArmor = "
                    + id);
            if (result.next()) {
                armor.setName(result.getString("name"));
                armor.setIconUrl(result.getString("iconUrl"));
                armor.setType(result.getInt("type"));
                armor.setProtection(result.getInt("protection"));
                armor.setDodgeRate(result.getFloat("dodgeRate"));
                armor.setLevel(result.getInt("level"));
                armor.setPrice(result.getInt("price"));
                armor.setId(result.getInt("idArmor"));
                return armor;
            }

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return null;
    }

    @Override
    public ArrayList<Armor> getAll() {
        ArrayList<Armor> armors = new ArrayList<>();
        Armor armor = new Armor();
        ResultSet result = DBManager.execute("SELECT * FROM armor");
        try {

            while (result.next()) {
                armor.setName(result.getString("name"));
                armor.setIconUrl(result.getString("iconUrl"));
                armor.setType(result.getInt("type"));
                armor.setProtection(result.getInt("protection"));
                armor.setDodgeRate(result.getInt("dodgeRate"));
                armor.setLevel(result.getInt("level"));
                armor.setPrice(result.getInt("price"));
                armor.setId(result.getInt("idArmor"));
                armors.add(armor);
            
            }
            return armors;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        
        int result = DBManager.executeUpdate("DELETE FROM armor WHERE idArmor=" + id + ";");
        return result == 0 ? false : true;

    }

    @Override
    public boolean createArmor(Armor armor) {
        String sql = "";
        if (armor.getId() == 0) {
            sql = "INSERT INTO armor (name,iconUrl,type,protection,dodgeRate,level,price)" +
                    "VALUES(?,?,?,?,?,?,?)";// 7 parameters
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, armor.getName());
                pstmt.setString(2, armor.getIconUrl());
                pstmt.setInt(3, armor.getType());
                pstmt.setInt(4, armor.getProtection());
                pstmt.setFloat(5, armor.getDodgeRate());
                pstmt.setInt(6, armor.getLevel());
                pstmt.setInt(7, armor.getPrice());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (armor.getId() == 0 && keys.next()) {
                    armor.setId(keys.getInt(1));
                    return true;
                } else if (armor.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;
    }

    @Override
    public boolean update(Armor armor) {
        String sql = "";
        if (armor.getId() != 0) {
            sql = "UPDATE armor " +
                    "SET name=?,iconUrl=?,type=?,protection=?,dodgeRate=?,level=?,price=? " +
                    "WHERE idArmor=?";
            try {
                PreparedStatement pstmt = DBManager.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, armor.getName());
                pstmt.setString(2, armor.getIconUrl());
                pstmt.setInt(3, armor.getType());
                pstmt.setInt(4, armor.getProtection());
                pstmt.setFloat(5, armor.getDodgeRate());
                pstmt.setInt(6, armor.getLevel());
                pstmt.setInt(7, armor.getPrice());
                pstmt.setInt(8, armor.getId());

                pstmt.executeUpdate();

                ResultSet keys = pstmt.getGeneratedKeys();
                if (armor.getId() == 0 && keys.next()) {
                    armor.setId(keys.getInt(1));
                    return true;
                } else if (armor.getId() != 0)
                    return true;
                else
                    return false;

            } catch (SQLException ex) {
                System.out.println("SQLException:" + ex.getMessage());
                System.out.println("SQLState:" + ex.getSQLState());
                System.out.println("VendorError:" + ex.getErrorCode());
                return false;
            }
        } else
            return false;

    }

}
