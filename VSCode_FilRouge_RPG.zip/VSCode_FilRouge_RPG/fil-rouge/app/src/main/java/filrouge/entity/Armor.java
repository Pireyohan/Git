package filrouge.entity;

import filrouge.allInterfaces.IEquiped;

public class Armor extends Item implements IEquiped {
    // #region attributs
    protected int type = 0;
    protected String iconUrl = "";
    protected int protection = 0;
    protected float dodgeRate = 0.2f;
    protected int level = 0;

    protected int price = 0;

    // #endregion attributs
    // #region constructeur
    public Armor() {
        super("jerem");
    }

    public Armor(String name, String iconUrl, int type, int protection, float dodgeRate, int price, int level) {
        super(name);
        this.type = type;
        this.iconUrl = iconUrl;
        this.protection = protection;
        this.dodgeRate = dodgeRate;
        this.price = price;
        this.level = level;
    }

    // #endregion constructeurs
    // public boolean get() {
    // try {
    // ResultSet result = DBManager.execute("SELECT * FROM armor WHERE idArmor = " +
    // this.id);
    // if (result.next()) {
    // this.name = result.getString("name");
    // this.iconUrl = result.getString("iconUrl");
    // this.type = result.getInt("type");
    // this.protection = result.getInt("protection");
    // this.dodgeRate = result.getFloat("dodgeRate");
    // this.level = result.getInt("level");
    // this.price = result.getInt("price");
    // return true;
    // }

    // } catch (Exception ex) {
    // System.out.println("SQLException: " + ex.getMessage());
    // System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
    // System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
    // }
    // return false;
    // }

    // public boolean get(int id) {
    // try {
    // ResultSet result = DBManager.execute("SELECT * FROM Armor WHERE idArmor = " +
    // id);
    // if (result.next()) {
    // this.name = result.getString("name");
    // this.iconUrl = result.getString("iconUrl");
    // this.type = result.getInt("type");
    // this.protection = result.getInt("protection");
    // this.dodgeRate = result.getFloat("dodgeRate");
    // this.level = result.getInt("level");
    // this.price = result.getInt("price");
    // this.id = id;
    // return true;
    // }

    // } catch (Exception ex) {
    // System.out.println("SQLException: " + ex.getMessage());
    // System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
    // System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
    // }
    // return false;

    // }

    // public boolean save() {
    // String sql;
    // if (this.id != 0)
    // sql = "UPDATE armor" +
    // "SET name = ? , iconUrl = ? , type = ? , protection = ? , dodgeRate = ? ,
    // level =? , price = ?" +
    // "WHERE idArmor = ?";
    // else
    // sql = "INSERT INTO armor (name , iconUrl ,type , protection , dodgeRate ,
    // level , price)" +
    // "VALUES(? , ? , ? , ? , ? ,? , ?)";

    // try {
    // PreparedStatement stmt = DBManager.conn.prepareStatement(sql,
    // Statement.RETURN_GENERATED_KEYS);

    // stmt.setString(1, this.name);
    // stmt.setString(2, this.iconUrl);
    // stmt.setInt(3, this.type);

    // stmt.setInt(4, this.protection);

    // stmt.setFloat(5, this.dodgeRate);
    // stmt.setInt(6, this.level);
    // stmt.setInt(7, this.price);

    // if (id != 0) {
    // stmt.setInt(8, this.id);
    // }

    // stmt.executeUpdate();

    // ResultSet keys = stmt.getGeneratedKeys();
    // if (this.id == 0 && keys.next()) {
    // this.id = keys.getInt(1);
    // return true;
    // } else if (this.id != 0)
    // return true;
    // else
    // return false;

    // } catch (SQLException ex) {
    // System.out.println("SQLException: " + ex.getMessage());
    // System.out.println("SQLState: " + ex.getSQLState());
    // System.out.println("VendorError: " + ex.getErrorCode());
    // return false;
    // }
    // }

    // #region getset
    public float getDodgeRate() {
        return dodgeRate;
    }

    public void setDodgeRate(float dodgeRate) {
        this.dodgeRate = dodgeRate;
    }

    public int getProtection() {
        return protection;
    }

    public void setProtection(int protection) {
        this.protection = protection;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getType() {
        return type;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public void setType(int type) {
        this.type = type;
    }
    // #endregion getset

}