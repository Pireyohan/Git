package filrouge.action;

import java.util.Random;
import java.util.Scanner;

import filrouge.allInterfaces.IBattleAction;
import filrouge.entity.Hero;
import filrouge.entity.Monster;

public class BattleHelper {
    static Random rng = new Random();
    static Scanner in = new Scanner(System.in);

    public static IBattleAction getBattleAction(Hero user, Monster target) {
        System.out.printf(MessageBuilder.inputPrompt(user.getName()));
        int action;
        do {
            action = in.nextInt();
        } while (action != 1 && action != 2);

        if (action == 1) {
            int damage = getRng(user.getStrength()) + 1;
            return new AttackAction(target, damage, MessageBuilder.attackAction(user.getName(), damage));
        } else {
            return new NoAction(MessageBuilder.noAction(user.getName()));
        }
    }

    public static void displayTurnResult(IBattleAction action, Monster enemy) {
        System.out.printf("%s", action.getResult());
        System.out.printf("%s health is now %d\n\n", enemy.getName(), enemy.getHpMax());
    }

    public static int getRng(int range) {
        return rng.nextInt(range);
    }
}
