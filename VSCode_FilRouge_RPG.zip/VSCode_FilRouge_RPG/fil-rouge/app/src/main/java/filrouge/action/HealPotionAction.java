package filrouge.action;

import filrouge.allInterfaces.IBattleAction;
import filrouge.entity.Hero;
import filrouge.entity.Monster;

public class HealPotionAction implements IBattleAction {

    public void execute(Hero user, Monster target) {
        int amount = BattleHelper.getRng(user.getHp() + 1);
        user.increaseHealth(amount);
    }

    public String toString() {
        return "placeholder text for take Potion";
    }

    @Override
    public void execute() {

    }

    @Override
    public String getResult() {

        return null;
    };
}
