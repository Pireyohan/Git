package filrouge.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import filrouge.allInterfaces.IMonster;
import filrouge.entity.Armor;
import filrouge.entity.Monster;
import filrouge.entity.Weapon;
import filrouge.utils.DBManager;

public class MonsterServices implements IMonster {

    @Override
    public Monster getById(int id) {
        Monster monster = new Monster();
        ResultSet result = DBManager.execute("SELECT * FROM monster WHERE idMonster = "
                + id);
        try {
            if (result.next()) {
                monster.setName(result.getString("name"));
                monster.setHp(result.getInt("hp"));
                monster.setStrength(result.getInt("strength"));
                monster.setDefense(result.getInt("defense"));
                monster.setSpeed(result.getInt("speed"));
                monster.setMoney(result.getInt("money"));
                monster.setExperience(result.getInt("experience"));
                monster.setCritical(result.getFloat("critical"));
                monster.setDodge(result.getFloat("dodge"));
                monster.setLevel(result.getInt("level"));

                Weapon weapon = new Weapon();
                WeaponServices weaponServices = new WeaponServices();
                weapon = weaponServices.getById(result.getInt("idWeaponEquiped"));
                // Todo vérifier si l'idWeapon n'existe pas en BDD
                monster.setWeapon(weapon);

                Armor armor = new Armor();
                ArmorServices armorServices = new ArmorServices();
                armor = armorServices.getById(result.getInt("idArmorEquiped"));
                // Todo vérifier si l'idArmor n'existe pas en BDD
                monster.setArmor(armor);

                monster.setId(id);

                return monster;
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }

        return null;
    }

    @Override
    public ArrayList<Monster> getAll() {
        ArrayList<Monster> monsters = new ArrayList<>();
        ResultSet result = DBManager.execute("SELECT * FROM monster WHERE idMonster; ");

        try {
            while (result.next()) {
                Monster tempMonster = new Monster();
                tempMonster.setName(result.getString("name"));
                tempMonster.setHp(result.getInt("hp"));
                tempMonster.setStrength(result.getInt("strength"));
                tempMonster.setDefense(result.getInt("defense"));
                tempMonster.setSpeed(result.getInt("speed"));
                tempMonster.setMoney(result.getInt("money"));
                tempMonster.setExperience(result.getInt("experience"));
                tempMonster.setCritical(result.getFloat("critical"));
                tempMonster.setDodge(result.getFloat("dodge"));
                tempMonster.setLevel(result.getInt("level"));
                Weapon weapon = new Weapon();
                Armor armor = new Armor();
                WeaponServices weaponServices = new WeaponServices();
                ArmorServices armorServices = new ArmorServices();
                weapon = weaponServices.getById(result.getInt("idWeaponEquiped"));
                armor = armorServices.getById(result.getInt("idArmorEquiped"));
                tempMonster.setWeapon(weapon);
                tempMonster.setArmor(armor);
                // TODO : vérifier que l'id de l'armure et weapon ne peut pas être null
                monsters.add(tempMonster);

            }
            return monsters;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ((SQLException) ex).getSQLState());
            System.out.println("VendoError: " + ((SQLException) ex).getErrorCode());
        }
        return null;
    }

}
