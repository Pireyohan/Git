package filrouge.entity;

import filrouge.action.FaintedAction;
import filrouge.allInterfaces.IBattleAction;

public class Hero extends Entity {
    // #region attributs
    protected String name;
    protected int idWeaponEquiped = 1;
    protected int idArmorEquiped = 1;
    protected String race = "";
    IBattleAction battleAction;
    // protected HashMap<ItemType, ArrayList<Item>> inventory = new HashMap<>();

    // let list ={
    // weapons: [epee, lance, arc],
    // armor: [carton, diamant],
    // potions: [eau; vin]

    // }

    // inventory.get(weapons).get(2);

    // #endregion attributs

    // #region constructor
    public Hero() {
        super();
    }

    public Hero(String name) {
        this.name = name;
    }
    // #endregion constructor

    // #region getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdWeaponEquiped() {
        return idWeaponEquiped;
    }

    public void setIdWeaponEquiped(int idWeaponEquiped) {
        this.idWeaponEquiped = idWeaponEquiped;
    }

    public int getIdArmorEquiped() {
        return idArmorEquiped;
    }

    public void setIdArmorEquiped(int idArmorEquiped) {
        this.idArmorEquiped = idArmorEquiped;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    // #endregion getters and setters

    // #region methods
    @Override
    public int attack() {
        return (int) (Math.random() * (hp / 4 + 1) + hp / 4 + 3);
    }

    public void move() {

    }

    public void runAway() {
    }

    public void openInventory() {
    }

    @Override
    public int defend() {

        return 0;
    }
    // #endregion methods

    // methods YO //
    public void takeTurn(IBattleAction chosenAction, Monster enemy) {
        if (hp > 0) {
            setBattleAction(chosenAction); // strategy
        } else {
            setBattleAction(new FaintedAction());
        }
        // performAction(enemy);
    }

    public void performAction(Hero target) {
        battleAction.execute();
    };

    public void decreaseHealth(int amount) {
        if (hp - amount < 0) {
            hp = 0;
        } else {
            hp -= amount;
        }
    }

    public void increaseHealth(int amount) {
        if (hp + amount > hpMax) {
            hp = hpMax;
        } else {
            hp += amount;
        }
    }

    public void setBattleAction(IBattleAction chosenAction) {
        battleAction = chosenAction;
    }

}
