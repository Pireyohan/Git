package filrouge;

import filrouge.entity.Hero;

import filrouge.help.Gamelogic;
import filrouge.services.HeroServices;
import filrouge.utils.DBManager;

public class App {

    public static void main(String[] args) {
        // Initialize connection to Bdd 2D_Adventure
        DBManager.init();
        // a utiliser plus tard
        // Arraylist<Monster> monstersList = new Arraylist<>();
        Gamelogic.startGame();

        // J'instancie un new hero services
        HeroServices heroServices = new HeroServices();

        // Je récupère l'Id n°1 dans la table héro
        Hero hero = heroServices.getById(1);
        System.out.println(hero.getName());
        //check je fais un changement blabla

        // //J'attends la class MonsterServices
        // MonsterServices monsterServices = new MonsterServices();
        // monsterServices.getAll();

        //Battle encounter = new Battle(hero, monster);

        // //todo method random pour random le monster mit dans la list monsterList
        // public static void randomMonsters(){
        // int rand =(int)(Math.random()*monstersList.length);

        // }
    }
}
