package filrouge.utils;

public class Vecteur2D {
    // #region attributs
    protected int x = 0;
    protected int y = 0;
    // #region attributs

    // #region constructors
    public Vecteur2D() {

    }

    public Vecteur2D(int x, int y) {
        this.x = x;
        this.y = y;
    }
    // #endregion constructors

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    // #region getters and setters

    // #endregion getters and setters
}
