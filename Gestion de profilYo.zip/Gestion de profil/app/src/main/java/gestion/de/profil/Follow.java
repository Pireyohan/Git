package gestion.de.profil;

public class Follow {

}
